
@extends('layouts.inventoryApp')

@section('content')
@include('layouts.headers.inventoryCard1')
<div class="container-fluid mt--7">
	<div class="card-body">
		<div class="col-xl-8 mb-5 mb-xl-0">
				<div class="card shadow">
						<div class="card-header border-0">
								<div class="row align-items-center">
									<div class="col">
									<h3 calss="mb-0">View Inventory</h3>
									<br>
									<h1 class="mb-0">{{$itemInfo[0]->itemName}}</h1>
										
									</div>
								</div>
						</div>
						<div class="card-body border-0">
								@foreach($errors->all() as $error)
								<div class="alert alert-danger" role="alert">
									<button type="button" data-dismiss="alert" class="close"><span aria-hidden="true">x</span></button>
										{{ $error }}<br>
								</div>
										
								@endforeach
							
							{!! Form::open(['action' => ['InventoryController@update', $itemInfo[0]->itemId], 'method' => 'POST']) !!}
							{{-- {{ Form::model($item, array('route' => array('inventory.update', $item->itemId), 'method' => 'PUT')) }} --}}
							<div class="row">
								<div class="col-md-12 mb-3">
									<label class="form-label">Item Name</label>
									{{-- <h3>{{ $itemInfo[0]->itemName }}</h3> --}}
									{{ Form::text('itemName', $itemInfo[0]->itemName, ['class' => 'form-control', 'placeholder' => 'Item Name' ] )}}
								</div>
								{{-- <div class="col-md-12 mb-3">
									<label class="form-label">Category</label>
									{{-- <h3>{{ $itemInfo[0]->categoryName }}</h3> --}}
									{{--  --}}
								{{-- </div> --}} 
								<div class="col-md-12 mb-3">
										<label class="form-label">Category</label>
										<select id="category" name="category" class="form-control" placeholder="Category" required>
												<option>-</option>
												@foreach ($categories as $category)
													@if ($category->categoryId == $itemInfo[0]->category)
														<option value="{{ $category->categoryId }}" id="categoryBal" selected>{{ $category->categoryName }}</option>
													@else
														<option value="{{ $category->categoryId }}" id="categoryBal" >{{ $category->categoryName }}</option>
													@endif
												@endforeach 
										</select>
										{{ Form::hidden('categoryVal', $itemInfo[0]->category, ['class' => 'form-control', 'placeholder' => 'Category'] )}}
								</div>
				<div class="col-md-12 mb-3">
					<label class="form-label">Quantity</label>
					<div class="row">
					{{-- <div class="col-md-4">
					<p>Current Quantity</p>
					</div> --}}
					<div class="col-md-12">
					{{ Form::number('quantity', $itemInfo[0]->quantity,['class' => 'form-control', 'placeholder' => 'Quantity to be Replenished'] )}}
					</div>
					
					</div>
				</div>
				
				{{-- <div class="col-md-12 mb-3">
						{{ Form::submit('Replenish Item', ['class' => 'btn btn-success']) }}
				</div> --}}
			</div>
								</div>
								<div class="card-footer text-muted">
										<div class="text-right">
												{{ Form::submit('Save Changes', ['class' => 'btn btn-success']) }}
												<a href="{{ url('inventory')}}" class="btn btn-default">Back</a>
												{{Form::hidden('_method', 'PUT')}}
										</div>
								</div>
						
		{!! Form::close() !!}
		</div>
		</div>
	</div>
</div>
@endsection