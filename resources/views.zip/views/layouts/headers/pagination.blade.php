{{-- <head>
<script type="text/javascript">
    function Pager(tableName, itemsPerPage) {
        this.tableName = tableName;
        this.itemsPerPage = itemsPerPage;
        this.currentPage = 1;
        this.pages = 0;
        this.inited = false;
        this.showRecords = function(from, to) {
            var rows = document.getElementById(tableName).rows;
            // i starts from 1 to skip table header row
            for (var i = 1; i < rows.length; i++) {
                if (i < from || i > to)
                    rows[i].style.display = 'none';
                else
                    rows[i].style.display = '';
            }
        }
        this.showPage = function(pageNumber) {
            if (!this.inited) {
                alert("not inited");
                return;
            }
            var oldPageAnchor = document.getElementById('pg' + this.currentPage);
            oldPageAnchor.className = 'pg-normal';
            this.currentPage = pageNumber;
            var newPageAnchor = document.getElementById('pg' + this.currentPage);
            newPageAnchor.className = 'pg-selected';
            var from = (pageNumber - 1) * itemsPerPage + 1;
            var to = from + itemsPerPage - 1;
            this.showRecords(from, to);
        }
        this.prev = function() {
            if (this.currentPage > 1)
                this.showPage(this.currentPage - 1);
        }
        this.next = function() {
            if (this.currentPage < this.pages) {
                this.showPage(this.currentPage + 1);
            }
        }
        this.init = function() {
            var rows = document.getElementById(tableName).rows;
            var records = (rows.length - 1);
            this.pages = Math.ceil(records / itemsPerPage);
            this.inited = true;
        }
        this.showPageNav = function(pagerName, positionId) {
            if (!this.inited) {
                alert("not inited");
                return;
            }
            var element = document.getElementById(positionId);
            var pagerHtml = '<span class="btn btn-sm" style="float:left; background-color:#DCDCDC; font-size:90%; color:gray" onclick="' + pagerName + '.prev();" class=""><b>&nbsp; « Prev &nbsp;</b></span> ';
            for (var page = 1; page <= this.pages; page++)
                pagerHtml += '<span style="font-size:90%;" id="pg' + page + '" class="pg-normal" onclick="' + pagerName + ' .showPage(' + page + ');"> <b>&emsp;' + page + '</b></span> ';
            pagerHtml += '<span class="btn btn-sm" style="float:right; background-color:#DCDCDC; font-size:90%; color:gray" onclick="' + pagerName + '.next();" class=""><b>&nbsp; Next » &nbsp;</b></span>';
            element.innerHTML = pagerHtml;
        }
    }
</script>
</head> --}}