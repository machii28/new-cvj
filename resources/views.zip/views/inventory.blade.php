@extends('layouts.inventoryApp')

{{-- @include('layouts.headers.pagination') --}}

@section('content')
    @include('layouts.headers.inventoryCard')

    <div class="container-fluid mt--7">
        <div class="card-body">
            {{-- <div class="col-xl-8 mb-5 mb-xl-0"> --}}
            <div class="col-xl-12 mb-5">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="row">
                                <div class="col-xs-5">
                                    <h1 class="mb-0">Inventory</h1>
                                </div>
                                <div class="col-xs-2">
                                        &nbsp;&nbsp;
                                </div>
                                <div class="col-xs-4">
                                    <a href="inventory/create" class="btn btn-sm btn-primary">+ Add Item</a>
                                </div>
                                </div>
                            </div>
                            <div class="col text-right">
                                {{-- <a href="inventory/create" class="btn btn-sm btn-primary">Add Item</a> --}}
                                
                            </div>
                            <div class="col text-left">
                                {{-- <div class="row"> --}}
                                    <div class="col-xs-5">
                                {{-- <input class="form-control" id="myInput" type="search" onkeyup="searchTable()" style="background: transparent;" placeholder="Search Item Here"> --}}
                                <input class="form-control" id="myInput" type="search" onkeyup="searchTable()" style="background: transparent;" placeholder="Search Item Here">
                                    </div>
                                    {{-- <div class="col-xs-2">
                                        &nbsp; &nbsp;
                                    </div> --}}
                                    {{-- <div class="col-xs-3">
                                    <button type="button" class="btn btn-md btn-block" onclick="seachTable()">Search</button>
                                    </div> --}}
                                {{-- </div> --}}
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                @if(session()->has('success'))
                                    <br>
                                    <div class="alert alert-success" role="alert">
                                        <button type="button" data-dismiss="alert" class="close"><span aria-hidden="true">x</span></button>
                                        {{ session()->get('success') }}<br>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <!-- Projects table -->
                        
                        <table class="table align-items-center table-flush" id="myTable">
                            <thead>
                                <tr>
                                    <th >Item name</th>
                                    <th >Stock Keeping Unit(SKU)</th>
                                    <th >Category</th>
                                    <th >Quantity</th>
                                    <th >Last Modified (YY-MM-DD)</th>
                                    <th >Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($joinedInventory as $i)
                                @if($i->status > 0)
                                <tr>
                                    <td>{{ $i->itemName }}</td>
                                <td><div id="barcode-{{$i->itemId}}" value="toPrint-{{$i->itemId}}">{!! DNS1D::getBarcodeHTML($i->sku, 'C128A') !!}</div></td>
                                    <td>{{ $i->categoryName }}</td>
                                    <td>{{ $i->quantity }}</td>
                                    {{-- <td>{{ $i->barcode }}</td> --}}
                                   
                                    <td>{{ $i->last_modified }}</td>
                                    <td>
                                        <div class="align-items-center">
                                        <ul class="navbar-nav align-items-center d-none d-md-flex btn-secondary">
                                            <li class="nav-item dropdown">
                                                <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <div class="media align-items-center">
                                                        {{-- <span class="avatar avatar-sm rounded-circle">
                                                            <img alt="Image placeholder" src="{{ asset('argon') }}/img/theme/team-4-800x800.jpg">
                                                        </span> --}}
                                                        <div class="d-lg-block">
                                                            <span class="mb-0 text-sm  font-weight-bold">Action</span>
                                                        </div>
                                                    </div>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-arrow dropdown-menu">
                                                    <div class=" dropdown-header noti-title">
                                                        <h6 class="text-overflow m-0">{{ __('Please Select an Action!') }}</h6>
                                                    </div>
                                                    <div class="dropdown-divider"></div>
                                                    <a href="{{ url('inventory/'.$i->itemId) }}" class="dropdown-item">
                                                        <i class="ni ni-zoom-split-in"></i>
                                                        <span>{{ __('View Item') }}</span>
                                                    </a>
                                                    <a href="{{ url('inventory/'.$i->itemId.'/edit')}}" class="dropdown-item">
                                                        <i class="ni ni-fat-add"></i>
                                                        <span>{{ __('Replenish Item') }}</span>
                                                    </a>
                                                <a href="#" class="dropdown-item" onclick="printContent('barcode-{{$i->itemId}}');" id="printBtn{{ $i->itemId}}">
                                                        <i class="ni ni-single-copy-04"></i>
                                                        <span>{{ __('Print Barcode') }}</span>
                                                    </a>
                                                    {{-- <a href="{{ url('')}}" class="dropdown-item">
                                                        <i class="ni ni-fat-delete"></i>
                                                        <span>{{ __('Remove from Inventory') }}</span>
                                                    </a> --}}
                                                <a href="" class="dropdown-item" onclick="event.preventDefault();
                                                        document.getElementById('delete-form-{{ $i->itemId }}').submit();">
                                                        <i class="ni ni-user-run"></i>
                                                        <span>{{ __('Remove from Inventory') }}</span>
                                                        {!! Form::open(['action' => ['InventoryController@destroy', $i->itemId], 'method' => 'POST', 'id' => 'delete-form-'.$i->itemId]) !!}
                                                            {{ Form::hidden('_method','DELETE')}}
                                                        {!! Form::close() !!}
                                                    </a>
                                                   
                                                </div>
                                            </li>
                                        </ul>
                                        </div>
                                        {{-- <a class="btn btn-sm btn-primary" href="inventory/{{ $i->itemId }}/edit"> Replenish Item </a> --}}
                                    </td>
                                </tr>
                                @endif
                                @endforeach
                            </tbody>
                        </table>
                    <!--pagination-->
                    <div id="pageNavPosition" style="padding-top: 20px; cursor: pointer;" align="center"></div>
                    <script type="text/javascript">
                        <!--
                        var pager = new Pager('myTable', 5);
                        pager.init();
                        pager.showPageNav('pager', 'pageNavPosition');
                        pager.showPage(1);
                    </script>
                    <!--pagination-->

                    </div>
                </div>
            </div>
        </div>
    @include('layouts.footers.auth')
    </div>
@endsection

@push('js')
    {{-- <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script> --}}
    {{-- <script>
        function searchTable() {
            // Declare variables 
            var input, filter, table, tr, td, i;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");
            // tr = table.getElementsByClassName("mamamo");
            th = table.getElementsByTagName("th");

            // Loop through all table rows, and hide those who don't match the search query
            for (i = 1; i < tr.length; i++) {
                tr[i].style.display = "none";
                for (var j = 0; j <= th.length; j++) {
                    td = tr[i].getElementsByTagName("td")[j];
                    if (td) {
                        if (td.innerHTML.toUpperCase().indexOf(filter.toUpperCase()) > -1) {
                            tr[i].style.display = "";
                            break;
                        }
                    }
                }
            }
        }

    </script> --}}
    <script>
        function printContent(el){
            var restorepage = $('body').html();
            var printcontent = $('#' + el).clone();
            $('body').empty().html(printcontent);
            window.print();
            $('body').html(restorepage);
        }
    </script>

@endpush