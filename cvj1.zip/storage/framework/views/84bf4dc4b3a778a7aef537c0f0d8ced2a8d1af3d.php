<?php $__env->startSection('title', 'BookEvent'); ?>



<?php $__env->startSection('content'); ?> 
    <?php echo $__env->make('layouts.headers.eventsCard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container-fluid mt--7">
            
            <div class="col-xl-12 mb-5">
                <div class="card shadow " >
                    <div class="card-header ">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="row">
                                <div class="col-xs-5">
                                    <h1 class="mb-0">Book Event</h1>
                                </div>
                                <div class="col-xs-2">
                                        &nbsp;&nbsp;
                                </div>
                               
                                </div>
                            </div>
                            <!-- <div class="col text-right">
                                
                                
                            </div> -->

                            <!-- <div class="col text-left">
                                
                                    <div class="col-xs-5">
                                
                                <input class="form-control" id="myInput" type="search" onkeyup="searchTable()" style="background: transparent;" placeholder="Search Item Here">
                                    </div>
                                    
                                    
                                
                            </div> -->
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <?php if(session()->has('success')): ?>
                                    <br>
                                    <div class="alert alert-success" role="alert">
                                        <button type="button" data-dismiss="alert" class="close"><span aria-hidden="true">x</span></button>
                                        <?php echo e(session()->get('success')); ?><br>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                            
                            <?php echo Form::open(['action' => 'BookEventController@store', 'method' => 'POST']); ?>

                            
                            <?php echo e(csrf_field()); ?>


                            <div class="col-md-4"> <h4> Event Name <font color="red">*</font></h4>
                                <?php echo e(Form::text('eventName', '', ['class' => 'form-control', 'placeholder' => 'Event Name', 'required' => 'true'])); ?>

                           </div>
                            
                           <div class="col-md-4"> <h4> Event Date <font color="red">*</font></h4>
                                   <?php echo e(Form::date('eventDate', '', ['class' => 'form-control', 'placeholder' => 'Date of Event', 'required' => 'true', 'min' => date("Y-m-d H:i:s")])); ?> 
                           </div>

                           <div class="col-md-4"> <h4> Event Venue </h4>
                            <select name="eventVenue" class = "form-control" form = "bookevent">
                                <option disabled> - Please Select a Venue - </option>
                                    <option value="01"> CVJ Hall A </option>
                                    <option value="02"> CVJ Hall B </option>
                                    <option value="03"> CVJ Hall C </option>
                                    <option value="04"> CVJ Hall D </option>
                                    <option value="05"> Other Venue </option>
                            </select>
                            </div>
                                   
                           <div class="col-md-4"> <h4> Event Type <font color="red">*</font></h4>
                                   <select name="eventType" class = "form-control" form = "bookevent" onchange="toggle(this.value)">
                                       <option disabled> - Please Select Event Type - </option>
                                           <option value="Wedding"> Wedding </option>
                                           <option value="Birthday"> Birthdays </option>
                                           <option value="Debut"> Baptismal </option>
                                           <option value="Business"> Business </option>
                                           <option value="Corporate"> Corporate </option>
                                           <option value="Others"> Others </option>
                                   </select>
                           </div>
                           
                           
                            <div class= "col-md-12 mb-3" id='test' style="display:none">
                                 <?php echo e(Form::text('eventType', '', ['class' => 'form-control', 'placeholder' => 'Others: Please Specify', 'required' => 'true'])); ?>

                            </div>

                            <div class="col-md-4"> <h4> Theme <font color="red">*</font></h4>
                                <?php echo e(Form::text('theme', '', ['class' => 'form-control', 'placeholder' => 'Theme', 'required' => 'true'])); ?>

                            </div>

                            <div class="col-md-4"> <h4> Centerpiece <font color="red">*</font></h4>
                                <?php echo e(Form::text('centerpiece', '', ['class' => 'form-control', 'placeholder' => 'Centerpiece', 'required' => 'true'])); ?>

                            </div>

                            <div class="col-md-4"> <h4> Flowers <font color="red">*</font></h4>
                                <?php echo e(Form::text('flowers', '', ['class' => 'form-control', 'placeholder' => 'Flowers', 'required' => 'true'])); ?>

                            </div>

                            <div class="col-md-4"> <h4> Linen Color <font color="red">*</font></h4>
                                <?php echo e(Form::text('linencolor', '', ['class' => 'form-control', 'placeholder' => 'Linen Color', 'required' => 'true'])); ?>

                            </div>
    
                            <div class="col-md-4"> <h4> Chair <font color="red">*</font></h4>
                                <?php echo e(Form::text('chair', '', ['class' => 'form-control', 'placeholder' => 'Chair', 'required' => 'true'])); ?>

                            </div>
    
                            <div class="col-md-4"> <h4> Table <font color="red">*</font></h4>
                                <?php echo e(Form::text('table', '', ['class' => 'form-control', 'placeholder' => 'Table', 'required' => 'true'])); ?>

                            </div>
    
                            <div class="col-md-4"> <h4> Others 
                                <?php echo e(Form::textarea('others', '', ['class' => 'form-control', 'placeholder' => 'Others (Optional)', 'required' => 'true'])); ?>

                            </div>

                            
                            <div class="col-md-4"> <h4> Total Pax <font color="red">*</font></h4>
                                <?php echo e(Form::number('totalPax', '', ['class' => 'form-control', 'placeholder' => 'Total Pax', 'required' => 'true'])); ?>

                            </div>
    
                            

                            <br>
                            <div class="col-md-12 mb-3">
                                    <p style="text-align:center">
                                         <?php echo e(Form::submit('Next: Add Book Event', ['class' => 'btn btn-success'])); ?> 
                                    </p>
                                 </div>
                                 
                                 <?php echo Form::close(); ?> 
                        </div>
                </div>
                <script>
                    function toggle(x){
                        if(x=="Others"){
                            var test=document.getElementById('test');
                             test.style.display="block";
                        }
                    }
                </script>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.eventApp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>