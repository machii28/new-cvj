<h1>CVJ Catering Services</h1>
<hr>
<b> Good Morning, Client</b>
<p> This is to remind you  ARE JEREMY that you have booked our event. Here are the terms of agreement for your reference. Please ignore if you already fulfilled the requirements</p>\
