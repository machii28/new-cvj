@extends('layout')


@section('title', 'About Us')

@section('content')
    <h1>About Us</h1>
    <h1> Not About Us </h1>
@endsection