@extends('layout')


@section('title', 'Contact Us')

@section('content')
    <h1>Contact Form</h1>
@endsection