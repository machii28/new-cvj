<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OutsourcedItem extends Model
{
    protected $table = 'outsourced_item';

}
