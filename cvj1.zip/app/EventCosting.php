<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GrabItem extends Model
{
    protected $table = 'event_costing';
}
