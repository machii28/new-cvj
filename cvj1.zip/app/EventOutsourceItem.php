<?php

namespace App;

use App\OutsourcedItem;
use Illuminate\Database\Eloquent\Model;

class EventOutsourceItem extends Model
{
    protected $table = 'event_outsource_item';
}
