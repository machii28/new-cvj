<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class events extends Model
{
    //
}
