<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\inventory;
use App\categoryRef;
use Illuminate\Support\Facades\DB;
use App\Http\Requests;
use Carbon\Carbon;
use Faker\Generator as Faker;

class InventoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $joinedTable = DB::table('category_ref')
            // ->join('category_ref','inventory.category','=','category_ref.id')
            ->join('inventory','category_ref.categoryId','=','inventory.category')
            ->get();
        //dd($joinedTable);
        
        return view('inventory', ['joinedInventory' => $joinedTable]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $category_ref = DB::table('category_ref')->get();

        return view('addInventoryForm', ['categories' => $category_ref]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Faker $faker)
    {
        
            $this->validate($request, [
                'itemName' => 'required',
                'category' => 'required|min:1',
                'quantity' => 'required|numeric|min:1'
            ],[
                'itemName.required' => 'Please Input a Valid Item Name.',
                'category.required' => 'Please Select a Category.',
                'quantity.required' => 'Invalid amount.'

            ]);

            //$faker = Faker::create();

            $inventory = new inventory();
            $inventory->itemName = $request->input('itemName');
            $inventory->category = $request->input('category');
            $inventory->quantity = $request->input('quantity');
            $inventory->sku = $faker->unique()->isbn13;
            $inventory->date_created = Carbon::now();
            $inventory->status = '1';
            //$inventory->last_modified = Carbon::now();
            $inventory->save();
            
            return redirect('inventory')->with('success', 'Item Added!');
        
            // DB::table('inventory')
            //     ->where()
            //     ->update();
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //

        $itemInfo = DB::table('category_ref')
            // ->join('category_ref','inventory.category','=','category_ref.id')
            ->select('*')
            ->where('inventory.itemId', '=', $id)
            ->join('inventory','category_ref.categoryId','=','inventory.category')
            ->get();
        //dd($joinedTable);

        $category_ref = DB::table('category_ref')->get();
        
        return view('inventoryView', ['itemInfo' => $itemInfo, 'categories' => $category_ref]);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //

        $item = DB::table('inventory')
        ->where('ItemId', '=', $id)
        ->get();
        
        $category = DB::table('category_ref')
        ->select('categoryName')
        ->where('itemId', '=', $id)
        ->join('inventory','category_ref.categoryId','=','inventory.category')
        ->get();

        //   dd($item);
        //   dd($category);
        return view('replenishInventory', ['items' => $item, 'category' => $category]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request, $id)
    {
        //

        $this->validate($request, [
            'quantity' => 'required|numeric|min:1'
        ],[
            'quantity.required' => 'Invalid amount.'

        ]);
        
        //dd($request->input('category'));

        $newQuantity = DB::table('inventory')
        ->select('quantity')
        ->where('itemId', '=', $id)
        ->get();

        $newQuantity = $newQuantity[0]->quantity + $request->input('quantity');

        
        $item = DB::table('inventory')
        ->where('itemId', '=', $id)
        ->update([
              //'category' => $request->input('category'),
            //   'quantity' => $request->input('quantity')
            'quantity' => $newQuantity,
            'last_modified' => Carbon::now(),
              ]);
        
        return redirect('/inventory')->with('success', 'Item Updated');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

     public function view(){

        $id = session()->get( 'id' );

        
     }

    public function destroy($id)
    {
        //
        // return alert('Are you sure you want to Continue?');

        $item = DB::table('inventory')
        ->where('itemId', '=', $id)
        ->update([
              //'category' => $request->input('category'),
            //   'quantity' => $request->input('quantity')
            'status' => '0',
            'last_modified' => Carbon::now(),
        ]);
        
        return redirect('/inventory')->with('success', 'Item Removed');
    }

    public function return(){
        return view('returnInventory');
    }
}
